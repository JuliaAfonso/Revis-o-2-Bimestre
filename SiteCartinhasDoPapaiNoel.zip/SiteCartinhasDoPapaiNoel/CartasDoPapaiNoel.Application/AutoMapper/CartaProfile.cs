﻿using AutoMapper;
using CartasDoPapaiNoel.Application.ViewModels;
using SiteCartinhasDoPapaiNoel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CartasDoPapaiNoel.Application.AutoMapper
{
    public class CartaProfile : Profile
    {
        public CartaProfile()
        {
            CreateMap<Carta, NovaCartaModel>();
            CreateMap<NovaCartaModel, Carta>();
        }
    }
}
