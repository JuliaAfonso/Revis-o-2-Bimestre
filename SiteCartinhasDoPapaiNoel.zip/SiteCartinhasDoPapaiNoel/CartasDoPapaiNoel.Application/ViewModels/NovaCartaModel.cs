﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CartasDoPapaiNoel.Application.ViewModels
{
    public class NovaCartaModel
    {
        [Required]
        [MinLength(3)]
        [MaxLength(255)]
        public string NomeDaCrianca { get; set; }

        public EnderecoModel Endereco { get; set; }

        public int Idade { get; set; }

        [MaxLength(500)]
        public string TextoDaCarta { get; set; }
        public object Id { get; internal set; }
    }

}