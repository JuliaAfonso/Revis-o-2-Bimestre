﻿using CartasDoPapaiNoel.Application.Interfaces;
using CartasDoPapaiNoel.Application.ViewModels;
using Microsoft.AspNetCore.Mvc;
using SiteCartinhasDoPapaiNoel.Models;

namespace SiteCartinhasDoPapaiNoel.Controllers
{
    [Route("api/cartinhas")]
    [ApiController]
    public class CartasController : ControllerBase
    {
        private readonly ICartaService _cartaService;

        public CartasController(ICartaService cartaService)
        {
            _cartaService = cartaService;
        }

        public ICartaService Get_cartaService()
        {
            return _cartaService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<NovaCartaModel>>> ObterTodasCartas(ICartaService _cartaService)
        {
            var cartas = await _cartaService.ObterTodasCartasAsync();
            return Ok(cartas);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<NovaCartaModel>> ObterCartaPorId(Guid id)
        {
            var carta = await _cartaService.ObterCartaPorIdAsync(id);
            if (carta == null)
                return NotFound();

            return Ok(carta);
        }

        [HttpPost]
        public async Task<IActionResult> AdicionarCarta(NovaCartaModel novaCarta)
        {
            await _cartaService.AdicionarCartaAsync(novaCarta);
            return CreatedAtAction(nameof(ObterCartaPorId), new { id = novaCarta.Id }, novaCarta);
        }
    }
}