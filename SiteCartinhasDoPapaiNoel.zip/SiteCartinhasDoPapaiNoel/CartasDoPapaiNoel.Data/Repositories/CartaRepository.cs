﻿using CartasDoPapaiNoel.Data.Context;
using CartasDoPapaiNoel.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using SiteCartinhasDoPapaiNoel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Formatting = Newtonsoft.Json.Formatting;

namespace CartasDoPapaiNoel.Data.Repositories
{
    public class CartaRepository : ICartaRepository
    {
        private readonly CartasDbContext _dbContext;

        public CartaRepository(CartasDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<Carta>> ObterTodasCartasAsync()
        {
            return await _dbContext.Cartas.ToListAsync();
        }

        public async Task<Carta> ObterCartaPorIdAsync(object id)
        {
            return await _dbContext.Cartas.FirstOrDefaultAsync(c => c.Id == id);
        }

        public async Task AdicionarCartaAsync(Carta carta)
        {
            _dbContext.Cartas.Add(carta);
            await _dbContext.SaveChangesAsync();
        }

        public void SeedData()
        {
            throw new NotImplementedException();
        }
    }
}