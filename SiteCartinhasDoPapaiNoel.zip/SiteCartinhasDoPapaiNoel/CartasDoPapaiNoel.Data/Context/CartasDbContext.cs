﻿using Microsoft.EntityFrameworkCore;
using SiteCartinhasDoPapaiNoel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace CartasDoPapaiNoel.Data.Context
{
    public class CartasDbContext : DbContext
    {
        public CartasDbContext(DbContextOptions<CartasDbContext> options) : base(options) { }
        public DbSet<Carta> Cartas { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}

